create definer = root@`%` trigger cmd_table_add
  after INSERT
  on cmd_table
  for each row
BEGIN insert into log_table(cmd_id,l_date,l_operation,l_flag) values(NEW.c_id,NOW(),'add',1); END;

