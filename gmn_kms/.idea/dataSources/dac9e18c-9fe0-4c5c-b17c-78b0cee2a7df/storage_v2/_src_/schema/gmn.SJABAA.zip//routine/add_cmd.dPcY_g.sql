create
  definer = root@`%` procedure add_cmd(IN request text, IN response text, IN describle char(255))
BEGIN insert into cmd_table(c_cmd,c_request,c_response,c_describle,c_flag) values(LEFT(request,2),request,response,describle,1); END;

